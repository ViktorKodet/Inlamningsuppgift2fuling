create
    definer = viktor@localhost procedure addToCart(IN kundIdIN int, IN beställningsIdIN int, IN skoIdIN int)
BEGIN
declare lastId int default 0;
declare exit handler for SQLEXCEPTION
begin
    rollback;
    select('Något gick fel, rollback utförd');
    resignal set message_text = 'Något gick fel, rollback utförd';
end;
declare exit handler for 1452
begin
    rollback;
    select('Felaktiga värden, rollback utförd');
    resignal set message_text = 'Felaktiga värden, rollback utförd';
end;

start transaction;
	if beställningsIdIN is null or (select count(*) from beställning where beställning.id like beställningsIdIN) = 0 then
    insert into beställning (kundid, datum) values (kundIdIN, curdate());
    select last_insert_id() into lastId;    
    insert into beställningsmap(skoId, beställningsId) values (skoIdIN, lastId);
    else
    insert into beställningsmap(skoId, beställningsId) values (skoIdIN, beställningsIdIN);
    end if;
    
    if (select sko.lagerstatus from sko where sko.id=skoIdIN) > 0 then
    update sko set lagerstatus = lagerstatus - 1 where sko.Id = skoIdIN;
    end if;
    
-- rollback;
commit;
	
END;

