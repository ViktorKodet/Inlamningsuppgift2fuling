create definer = viktor@localhost view ratings as
select `s`.`namn` AS `namn`, round(`prodAvg`(`s`.`id`), 1) AS `AverageRating`, `b`.`betygtext` AS `betygtext`
from (`skodb2`.`sko` `s`
         left join `skodb2`.`betyg` `b` on ((`b`.`värde` = round(`prodAvg`(`s`.`id`), 0))))
order by `b`.`värde` desc;

