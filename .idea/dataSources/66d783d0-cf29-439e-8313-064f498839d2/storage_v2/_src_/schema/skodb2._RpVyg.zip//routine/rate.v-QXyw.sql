create
    definer = root@localhost procedure rate(IN skoidIN int, IN kundidIN int, IN betygIN int,
                                            IN kommentarIN varchar(16000))
BEGIN
declare exit handler for 1452
    begin
    rollback;
    select ('Felaktiga värden');
    resignal set message_text = 'Felaktiga värden';
end;
declare exit handler for sqlexception
begin
    rollback;
    select ('Något gick fel, rollback utförd');
    resignal set message_text = 'Något gick fel, rollback utförd';
end;

start transaction;
insert into betygsättning (skoid, kundid, betyg, kommentar) values (skoidIN, kundidIN, betygIN, kommentarIN);
-- select * from betygsättning;
-- rollback;
commit;
END;

