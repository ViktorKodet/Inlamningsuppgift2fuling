create
    definer = root@localhost procedure getProdAvg(IN productId int, OUT average double)
begin
	set average = round(prodAvg(productId), 1);
end;

