create definer = root@localhost trigger after_lagerstatus_update
    after update
    on sko
    for each row
begin 
	if new.lagerstatus = 0 then
    insert into slutilager(skoId) values (new.id);
    end if;
end;

