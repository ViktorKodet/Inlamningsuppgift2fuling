create
    definer = root@localhost function prodAvg(productId int) returns float
begin
	declare temp float default 0;
	select avg(betyg) into temp from betygsättning where skoid=productId;
	return temp;
end;

